
$.extend(Template.header, { 
    brand : "<img id='theDudeImg' src='the-dude.jpg' width=128 height=128 />",
    home : "Accueil",
    play : "Jouer !",
    about : "A propos"
});

