
config = {
    world : {
        width : 800,
        height : 600
    },
    canvas : {
        width : 800,
        height : 600
    },
    ropeLength : 200
};
